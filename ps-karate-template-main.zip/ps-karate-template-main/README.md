# Pluralsight - Karate Fundamentals - Template Project

This repository is a simple Karate template to support the Pluralsight course [Karate Fundamentals](https://pluralsight.com)

It contains the skeleton files required to start building a Karate automation testing framework.
